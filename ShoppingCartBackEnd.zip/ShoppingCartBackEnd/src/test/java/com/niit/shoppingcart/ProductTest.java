package com.niit.shoppingcart;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcart.dao.ProductDAO;
import com.niit.shoppingcart.model.Product;

public class ProductTest {
	
	public static void main(String[] args) {
		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();

		context.scan("com.niit.shoppingcart");
		context.refresh();
		
		ProductDAO productDAO = (ProductDAO) context.getBean("productDAO");
		
		Product product = (Product) context.getBean("product");
		product.setId("P120");
		product.setName("PName120");
		product.setDescription("PDesc120");
		product.setPrice("PPrice");
		productDAO.saveOrUpdate(product);

/*		
		if(productDAO.get("sdfsf") == null)
		{
			System.out.println("Product does not exist");
		}
		else
		{
			System.out.println("Product exist... The Details are...");
			System.out.println();
		}

*/
//		productDAO.delete("CG120");
		
		
	}

}

/*
 select * from Product
 */

